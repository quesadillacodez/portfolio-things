# Hadi Qusyairi Portfolio

A responsive, single-page React portfolio focused on practical software, analytics, and operational problem solving.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Project content is kept in `src/data/projects.js` so links and outcomes can be updated without changing the UI components. Add Hadi's GitHub profile and repository URLs there once they are available.
